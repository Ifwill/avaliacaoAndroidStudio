package com.example.avaliacaosenai;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    Double livro1,livro2,livro3,livro4,livro5, vTotal;

    CheckBox cb_1,cb_2,cb_3,cb_4,cb_5;
    EditText edt_1,edt_2,edt_3,edt_4,edt_5;
    Button button;
    TextView txt_resultado;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        cb_1 = (CheckBox)findViewById(R.id.cb_1);
        cb_2 = (CheckBox)findViewById(R.id.cb_2);
        cb_3 = (CheckBox)findViewById(R.id.cb_3);
        cb_4 = (CheckBox)findViewById(R.id.cb_4);
        cb_5 = (CheckBox)findViewById(R.id.cb_5);

        edt_1 = (EditText)findViewById(R.id.edt_1);
        edt_2 = (EditText)findViewById(R.id.edt_2);
        edt_3 = (EditText)findViewById(R.id.edt_3);
        edt_4 = (EditText)findViewById(R.id.edt_4);
        edt_5 = (EditText)findViewById(R.id.edt_5);

        livro1 = 1.0;
        livro2 = 1.0;
        livro3 = 1.0;
        livro4 = 1.0;
        livro5 = 1.0;

        button = (Button) findViewById(R.id.button);

        txt_resultado = (TextView)findViewById(R.id.txt_resultado);
    }

    public void result(View v){

        vTotal = 0.0;

        if(cb_1.isChecked()){
            vTotal += livro1 * Double.parseDouble(edt_1.getText().toString());
        }
        if(cb_2.isChecked()){
            vTotal += livro2 * Double.parseDouble(edt_2.getText().toString());
        }
        if(cb_3.isChecked()){
            vTotal += livro3 * Double.parseDouble(edt_3.getText().toString());
        }
        if(cb_4.isChecked()){
            vTotal += livro4 * Double.parseDouble(edt_4.getText().toString());
        }
        if(cb_5.isChecked()){
            vTotal += livro5 * Double.parseDouble(edt_5.getText().toString());
        }

        txt_resultado.setText("Valor total: R$"+String.valueOf(vTotal));

    }
}